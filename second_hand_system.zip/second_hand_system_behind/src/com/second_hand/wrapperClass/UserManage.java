package com.second_hand.wrapperClass;

public class UserManage {
	private int userid;
	private String nickname;
	private String email;
	private String phone;
	private String qq;
	private String schoolname;
	private String departname;
	private String address;
	
	public int getUserid() {
		return userid;
	}
	
	public void setUserid(int userid) {
		this.userid=userid;
	}
	
	public String getNickname() {
		return nickname;
	}
	
	public void setNickname(String nickname) {
		this.nickname=nickname;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email=email;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone=phone;
	}
	
	public String getQq() {
		return qq;
	}
	
	public void setQq(String qq) {
		this.qq=qq;
	}
	
	public String getSchoolname() {
		return schoolname;
	}
	
	public void setSchoolname(String schoolname) {
		this.schoolname=schoolname;
	}
	
	public String getDepartname() {
		return departname;
	}
	
	public void setDepartname(String departname) {
		this.departname=departname;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address=address;
	}
}
