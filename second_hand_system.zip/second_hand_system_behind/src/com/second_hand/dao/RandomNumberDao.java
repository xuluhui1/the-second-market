package com.second_hand.dao;

public abstract class RandomNumberDao {
	public abstract String getOrderIdByUUId();
	public abstract String getXiooByUUId();
}
