package com.second_hand.model;

public class Depart {
	private int departid;//院级编号
	private String departname;//院级名称
	
	public int getDepartid() {
		return departid;
	}
	
	public void setDepartid(int departid) {
		this.departid = departid;
	}
	public String getDepartname() {
		return departname;
	}
	public void setDepartname(String departname) {
		this.departname = departname;
	}
}
