package com.second_hand.model;

public class Goodsclass {
	private int classid;//商品类型编号
	private String classname;//商品类型名称
	
	public int getClassid() {
		return classid;
	}
	
	public void setClassid(int classid) {
		this.classid = classid;
	}
	public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}
}
