package com.second_hand.model;

public class School {
	private int schoolid;//学校编号
	private String schoolname;//学校名称
	
	public int getSchoolid() {
		return schoolid;
	}
	
	public void setSchoolid(int schoolid) {
		this.schoolid = schoolid;
	}
	public String getSchoolname() {
		return schoolname;
	}
	public void setSchoolname(String schoolname) {
		this.schoolname = schoolname;
	}
}
